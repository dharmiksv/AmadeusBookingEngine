# CollectionLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_self** | **str** |  | [optional] 
**next** | **str** |  | [optional] 
**previous** | **str** |  | [optional] 
**last** | **str** |  | [optional] 
**first** | **str** |  | [optional] 
**up** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


