# Dictionaries

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**locations** | [**LocationEntry**](LocationEntry.md) |  | [optional] 
**aircraft** | [**AircraftEntry**](AircraftEntry.md) |  | [optional] 
**currencies** | [**CurrencyEntry**](CurrencyEntry.md) |  | [optional] 
**carriers** | [**CarrierEntry**](CarrierEntry.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


