# OriginalFlightEndPoint

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iata_code** | **str** | [IATA airline codes](http://www.iata.org/publications/Pages/code-search.aspx) | [optional] 
**terminal** | **str** | terminal name / number | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


