# SearchCriteria

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exclude_allotments** | **bool** | This option allows to exclude the isAllotment flag associated to a booking class in the search response when it exist. | [optional] 
**add_one_way_offers** | **bool** | This option allows activate the one-way combinable feature | [optional] 
**max_flight_offers** | **float** | Maximum number of flight offers returned (Max 250) | [optional] 
**max_price** | **int** | maximum price per traveler. By default, no limit is applied. If specified, the value should be a positive number with no decimals | [optional] 
**allow_alternative_fare_options** | **bool** | This option allows to default to a standard fareOption if no offers are found for the selected fareOption. | [optional] 
**one_flight_offer_per_day** | **bool** | Requests the system to find at least one flight-offer per day, if possible, when a range of dates is specified. Default is false. | [optional] 
**additional_information** | [**AdditionalInformation**](AdditionalInformation.md) |  | [optional] 
**pricing_options** | [**ExtendedPricingOptions**](ExtendedPricingOptions.md) |  | [optional] 
**flight_filters** | [**FlightFilters**](FlightFilters.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


