# ExtendedPrice

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**currency** | **str** |  | [optional] 
**total** | **str** | Total amount paid by the user | [optional] 
**base** | **str** | Amount without taxes | [optional] 
**fees** | [**list[Fee]**](Fee.md) | List of applicable fees | [optional] 
**taxes** | [**list[Tax]**](Tax.md) |  | [optional] 
**refundable_taxes** | **str** | The amount of taxes which are refundable | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


