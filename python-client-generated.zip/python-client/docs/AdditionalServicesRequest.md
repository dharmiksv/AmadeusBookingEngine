# AdditionalServicesRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chargeable_checked_bags** | [**BaggageAllowance**](BaggageAllowance.md) | Details of chargeable checked bags | [optional] 
**chargeable_seat_number** | **str** | seat number | [optional] 
**other_services** | [**list[ServiceName]**](ServiceName.md) | Other services to add | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


