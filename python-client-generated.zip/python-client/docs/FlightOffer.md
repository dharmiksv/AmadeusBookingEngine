# FlightOffer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | the resource name | 
**id** | **str** | Id of the flight offer | 
**source** | [**FlightOfferSource**](FlightOfferSource.md) |  | 
**instant_ticketing_required** | **bool** | If true, inform that a ticketing will be required at booking step. | [optional] 
**disable_pricing** | **bool** | BOOK step ONLY - If true, allows to book a PNR without pricing. Only for the source \&quot;GDS\&quot; | [optional] 
**non_homogeneous** | **bool** | If true, upon completion of the booking, this pricing solution is expected to yield multiple records (a record contains booking information confirmed and stored, typically a Passenger Name Record (PNR), in the provider GDS or system) | [optional] 
**one_way** | **bool** | If true, the flight offer fulfills only one originDestination and has to be combined with other oneWays to complete the whole journey. | [optional] 
**payment_card_required** | **bool** | If true, a payment card is mandatory to book this flight offer | [optional] 
**last_ticketing_date** | **str** | If booked on the same day as the search (with respect to timezone), this flight offer is guaranteed to be thereafter valid for ticketing until this date (included). Unspecified when it does not make sense for this flight offer (e.g. no control over ticketing once booked). YYYY-MM-DD format, e.g. 2019-06-07 | [optional] 
**number_of_bookable_seats** | **float** | Number of seats bookable in a single request. Can not be higher than 9. | [optional] 
**itineraries** | [**list[Itineraries]**](Itineraries.md) |  | [optional] 
**price** | [**ExtendedPrice**](ExtendedPrice.md) |  | [optional] 
**pricing_options** | [**PricingOptions**](PricingOptions.md) |  | [optional] 
**validating_airline_codes** | **list[str]** | This option ensures that the system will only consider these airlines. | [optional] 
**traveler_pricings** | [**list[TravelerPricing]**](TravelerPricing.md) | Fare information for each traveler/segment | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


