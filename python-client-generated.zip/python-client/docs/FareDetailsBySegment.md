# FareDetailsBySegment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**segment_id** | **str** | Id of the segment | 
**cabin** | [**TravelClass**](TravelClass.md) |  | [optional] 
**fare_basis** | **str** | Fare basis specifying the rules of a fare. Usually, though not always, is composed of the booking class code followed by a set of letters and digits representing other characteristics of the ticket, such as refundability, minimum stay requirements, discounts or special promotional elements. | [optional] 
**branded_fare** | **str** | The name of the Fare Family corresponding to the fares. Only for the GDS provider and if the airline has fare families filled | [optional] 
**_class** | **str** | The code of the booking class, a.k.a. class of service or Reservations/Booking Designator (RBD) | [optional] 
**is_allotment** | **bool** | True if the corresponding booking class is in an allotment | [optional] 
**allotment_details** | [**AllotmentDetails**](AllotmentDetails.md) |  | [optional] 
**slice_dice_indicator** | [**SliceDiceIndicator**](SliceDiceIndicator.md) |  | [optional] 
**included_checked_bags** | [**BaggageAllowance**](BaggageAllowance.md) | Details of the included checked bags | [optional] 
**additional_services** | [**AdditionalServicesRequest**](AdditionalServicesRequest.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


