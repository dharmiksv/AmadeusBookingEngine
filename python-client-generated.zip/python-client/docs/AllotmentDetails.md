# AllotmentDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tour_name** | **str** |  | [optional] 
**tour_reference** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


