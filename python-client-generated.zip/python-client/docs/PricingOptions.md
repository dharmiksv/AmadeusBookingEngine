# PricingOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fare_type** | [**PricingOptionsFareType**](PricingOptionsFareType.md) | type of fare of the flight-offer | [optional] 
**corporate_codes** | **list[str]** | Allow Corporate negotiated fares using one or more corporate number (corporate code). | [optional] 
**included_checked_bags_only** | **bool** | If true, returns the flight-offers with included checked bags only | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


