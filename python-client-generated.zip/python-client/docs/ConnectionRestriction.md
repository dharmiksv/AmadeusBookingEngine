# ConnectionRestriction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**max_number_of_connections** | **float** | The maximal number of connections for each itinerary. Value can be 0, 1 or 2. | [optional] 
**airport_change_allowed** | **bool** | Allow to change airport during connection | [optional] 
**technical_stops_allowed** | **bool** | This option allows the single segment to have one or more intermediate stops (technical stops). | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


