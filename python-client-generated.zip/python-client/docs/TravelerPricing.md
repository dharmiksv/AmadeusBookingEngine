# TravelerPricing

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**traveler_id** | **str** | Id of the traveler | 
**fare_option** | [**TravelerPricingFareOption**](TravelerPricingFareOption.md) |  | 
**traveler_type** | [**TravelerType**](TravelerType.md) |  | 
**associated_adult_id** | **str** | if type&#x3D;\&quot;HELD_INFANT\&quot;, corresponds to the adult traveler&#39;s id who will share the seat | [optional] 
**price** | [**Price**](Price.md) | price detail of the traveler | [optional] 
**fare_details_by_segment** | [**list[FareDetailsBySegment]**](FareDetailsBySegment.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


