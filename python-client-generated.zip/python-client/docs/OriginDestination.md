# OriginDestination

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**origin_location_code** | **str** | Origin location, such as a city or an airport. Currently, only the locations defined in [IATA](http://www.iata.org/publications/Pages/code-search.aspx) are supported. | [optional] 
**origin_radius** | **float** | Include other possible locations around the point, located less than this distance in kilometers away. Max:300 | [optional] 
**alternative_origins_codes** | **list[str]** | Set of alternative origin location, such as a city or an airport. Currently, only the locations defined in [IATA](http://www.iata.org/publications/Pages/code-search.aspx) are supported. | [optional] 
**destination_location_code** | **str** | Destination location, such as a city or an airport. Currently, only the locations defined in [IATA](http://www.iata.org/publications/Pages/code-search.aspx) are supported. | [optional] 
**destination_radius** | **float** | Include other possible locations around the point, located less than this distance in kilometers away. Max:300 | [optional] 
**alternative_destinations_codes** | **list[str]** | Set of alternative destination location, such as a city or an airport. Currently, only the locations defined in [IATA](http://www.iata.org/publications/Pages/code-search.aspx) are supported. | [optional] 
**departure_date_time_range** | [**DateTimeRange**](DateTimeRange.md) | Approximate date and time of departure, specified as a local date and time range. | [optional] 
**arrival_date_time_range** | [**DateTimeRange**](DateTimeRange.md) | Approximate date and time of arrival, specified as a local date and time range. | [optional] 
**included_connection_points** | **list[str]** | List of included connections points. When an includedViaPoints option is specified, all FlightOffer returned must at least go via this Connecting Point. Currently, only the locations defined in IATA are supported. Used only by the AMADEUS provider | [optional] 
**excluded_connection_points** | **list[str]** | List of excluded connections points. Any FlightOffer with these connections points will be present in response. Currently, only the locations defined in IATA are supported. Used only by the AMADEUS provider | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


