# OriginalFlightStop

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**iata_code** | **str** | [IATA airline codes](http://www.iata.org/publications/Pages/code-search.aspx) | [optional] 
**duration** | **str** | stop duration in [ISO8601](https://en.wikipedia.org/wiki/ISO_8601) PnYnMnDTnHnMnS format, e.g. PT2H10M | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


