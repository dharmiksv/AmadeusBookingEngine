# AdditionalInformation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chargeable_checked_bags** | **bool** | If true, returns the price of the first additional bag when the airline is an \&quot;Amadeus Ancillary Services\&quot; member. | [optional] 
**branded_fares** | **bool** | If true, returns the fare family name for each flight-offer which supports fare family | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


