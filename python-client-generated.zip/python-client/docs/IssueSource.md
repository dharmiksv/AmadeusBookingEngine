# IssueSource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pointer** | **str** | a JSON Pointer [RFC6901] to the associated entity in the request document | [optional] 
**parameter** | **str** | a string indicating which URI query parameter caused the issue | [optional] 
**example** | **str** | a string indicating an example of the right value | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


