# Traveler

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | 
**traveler_type** | [**TravelerType**](TravelerType.md) |  | 
**associated_adult_id** | **str** | if type&#x3D;\&quot;HELD_INFANT\&quot;, corresponds to the adult travelers&#39;s id who will share the seat | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


