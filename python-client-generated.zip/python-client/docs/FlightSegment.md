# FlightSegment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**departure** | [**FlightEndPoint**](FlightEndPoint.md) |  | [optional] 
**arrival** | [**FlightEndPoint**](FlightEndPoint.md) |  | [optional] 
**carrier_code** | **str** | providing the airline / carrier code | [optional] 
**number** | **str** | the flight number as assigned by the carrier | [optional] 
**aircraft** | [**AircraftEquipment**](AircraftEquipment.md) |  | [optional] 
**operating** | [**OperatingFlight**](OperatingFlight.md) |  | [optional] 
**duration** | **str** | stop duration in [ISO8601](https://en.wikipedia.org/wiki/ISO_8601) PnYnMnDTnHnMnS format, e.g. PT2H10M | [optional] 
**stops** | [**list[FlightStop]**](FlightStop.md) | information regarding the different stops composing the flight segment. E.g. technical stop, change of gauge... | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


