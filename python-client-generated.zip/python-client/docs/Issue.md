# Issue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **int** | the HTTP status code applicable to this error | [optional] 
**code** | **int** | an application-specific error code | [optional] 
**title** | **str** | a short summary of the error | [optional] 
**detail** | **str** | explanation of the error | [optional] 
**source** | [**IssueSource**](IssueSource.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


