# LocationValue

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**city_code** | **str** | City code associated to the airport | [optional] 
**country_code** | **str** | Country code of the airport | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


