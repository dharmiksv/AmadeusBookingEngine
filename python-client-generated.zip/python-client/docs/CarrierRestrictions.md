# CarrierRestrictions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**blacklisted_in_eu_allowed** | **bool** | This flag enable/disable filtering of blacklisted airline by EU. The list of the banned airlines is published in the Official Journal of the European Union, where they are included as annexes A and B to the Commission Regulation. The blacklist of an airline can concern all its flights or some specific aircraft types pertaining to the airline | [optional] 
**excluded_carrier_codes** | **list[str]** | This option ensures that the system will only consider these airlines. | [optional] 
**included_carrier_codes** | **list[str]** | This option ensures that the system will only consider these airlines. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


