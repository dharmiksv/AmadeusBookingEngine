# BaggageAllowance

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**quantity** | **int** | Total number of units | [optional] 
**weight** | **int** | Weight of the baggage allowance | [optional] 
**weight_unit** | **str** | Code to qualify unit as pounds or kilos | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


