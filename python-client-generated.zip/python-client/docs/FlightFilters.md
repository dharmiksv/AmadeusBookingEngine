# FlightFilters

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cross_border_allowed** | **bool** | Allows to search a location outside the borders when a radius around a location is specified. Default is false. | [optional] 
**more_overnights_allowed** | **bool** | This flag enables/disables the possibility to have more overnight flights in Low Fare Search | [optional] 
**return_to_departure_airport** | **bool** | This option force to retrieve flight-offer with a departure and a return in the same airport | [optional] 
**rail_segment_allowed** | **bool** | This flag enable/disable filtering of rail segment (TGV AIR, RAIL ...) | [optional] 
**bus_segment_allowed** | **bool** | This flag enable/disable filtering of bus segment | [optional] 
**max_flight_time** | **float** | This option allows to modify the value for the Elapsed Flying Time (EFT) masterPricer option | [optional] 
**carrier_restrictions** | [**CarrierRestrictions**](CarrierRestrictions.md) |  | [optional] 
**cabin_restrictions** | [**list[CabinRestriction]**](CabinRestriction.md) | Restriction towards cabins. | [optional] 
**connection_restriction** | [**ConnectionRestriction**](ConnectionRestriction.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


